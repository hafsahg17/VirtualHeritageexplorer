VIRTUAL HERITAGE EXPLORER - MP3 AUDIO UPDATE

This bundle contains five updated HTML pages and their matching MP3 narrations.

UPLOAD TO GITHUB:
1. Open your virtualheritage-explorer repository.
2. Upload/replace the five HTML files in the repository root.
3. Create a folder named audio in the repository root.
4. Upload all five MP3 files into that audio folder.
5. Commit the changes.

Keep the filenames and folder structure exactly as provided:
- charminar.html + audio/charminar.mp3
- hampi.html + audio/hampi.mp3
- mysore-palace.html + audio/mysore-palace.mp3
- taj-mahal.html + audio/taj-mahal.mp3
- tirupati.html + audio/tirupati.mp3

The narration MP3s in this bundle use a basic synthetic English voice.
